-EX1 

Bueno aqui lo que hacemos es el scanner para que recoga y lea los nombres que se pican y despues printea el resultado, y despues en el  
"public static String obtener(String nombreCompleto)" divido la variable nombre completo en una array de nombre y apellidos. Luego  
itero sobre el nombre y pido la primera letra y despues printeo el apellido completo. 

  

-EX2 

En este pedimos  que introduzca dos lineas las que quiera y despues printeamos el resultado juntandolas, despues 
creo un StringBuilder para contruir la cadena final. Despues, itero a traves de la candena1 y cadena2.Y por ultimo
printeamos el resultado


-EX3

Pedimos que nos de una frase y despues un caracter, llamamos el metodo encontrar para encontrar las posiciones del caracter en 
la frase, y printeamos erl resultado.
Y en el metodo "public static int[] encontrar(String frase, char caracter) " creamos un arreglo para almacenar las posciones 
del caracter, y por ultimo hacemos el return para que lo devuelva.


-EX4

Pedimos una frase y despues un Caracter, despues creo una lista para almacenar la posicion del caracter, despues
buscamos el primer caracter de la frase, se itera para encontrar la letra que hay en el caracter y se printea el 
resultado

-EX5

Pedimos que ponga una contraseña, despues se valida si la constraseña es fuerte o no con el metodo "esContraseñaFuerte"
en el cual hacemos un if para saber si la contraseña es menor que 8 caracteres si tiene menos no es segura o si tiene mas
si es segura y a parte si tieneMayuscula, Minuscula, Simbolo o Digitos y printeamos el resultado si es fuerte o no.

-EX6

Se inicializa una cadena de texto. Luego, se imprime un encabezado y se itera sobre cada caracter de la cadena. Para cada caracter, 
se obtiene su valor ASCII y se imprime junto con el caracter correspondiente.


-EX7

Creamos un arrayList de numeros enteros Luego, se obtiene un Iterator para el ArrayList. Se imprime un mensaje indicando los elementos del ArrayList y luego se 
itera sobre el ArrayList utilizando el Iterator. En cada iteración, se obtiene y muestra un elemento del ArrayList.


-EX08

Creamos una cadena de lista en este caso con el mejor equipo del mundo el "Barça". y por ultimo se utiliza un forEach
para imprimir cada elemento de la lista

-EX09

Creamos una lista de cadenas, despues convertimos una lista en una array de cadenas y por ultimo se itera sobre el array
utilizando un bucle y printeamos el resultado

-EX10

Creamos un HashSet de cadenas, despues printeamos Equipo para que se vea antes que el resultado que es cuando iteramos
sobre el HashSet utilizando un bucle for-each y por ultimo imprimimos el resultado

-EX11

Creamos un HashMap con claves unicas y sus valores, despues convertimos el mapa en una lista de pares (clave,valor) 
se ordena la lista por los valores de forma ascendente, despues creamos un TreeMap para almacenar los valores y por
ultimo printeamos el resultado ordenado.


