package EjerciciosCadenas;

import java.util.ArrayList;
import java.util.List;

public class EX_08 {
    public static void main(String[]args){
        List<String> l = new ArrayList<>();
        l.add("TerStegen");
        l.add("Lewandoski");
        l.add("Pedri");
        l.add("Raphina");

        l.forEach(barça -> System.out.print(barça));

    }
    }

    

