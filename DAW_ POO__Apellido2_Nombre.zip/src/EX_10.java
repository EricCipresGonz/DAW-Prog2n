package EjerciciosCadenas;

import java.util.HashSet;

public class EX_10 {
    public static void main(String[]args){
        HashSet<String> team= new HashSet<>();
        team.add("TerStegen");
        team.add("Lewandoski");
        team.add("Pedri");
        team.add("Raphina");

        System.out.println("Equipo: ");
        for (String barça : team){
            System.out.println(barça);
        }

    }
    }

    


